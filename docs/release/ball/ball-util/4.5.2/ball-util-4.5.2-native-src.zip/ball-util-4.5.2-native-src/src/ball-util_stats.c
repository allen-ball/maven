
#include "hawtjni.h"
#include "ball-util_stats.h"

#ifdef NATIVE_STATS

int JNI_nativeFunctionCount = 5;
int JNI_nativeFunctionCallCount[5];
char * JNI_nativeFunctionNames[] = {
	"init",
	"uuid_1clear",
	"uuid_1generate",
	"uuid_1generate_1random",
	"uuid_1generate_1time",
};

#define STATS_NATIVE(func) Java_org_fusesource_hawtjni_runtime_NativeStats_##func

JNIEXPORT jint JNICALL STATS_NATIVE(JNI_1GetFunctionCount)
	(JNIEnv *env, jclass that)
{
	return JNI_nativeFunctionCount;
}

JNIEXPORT jstring JNICALL STATS_NATIVE(JNI_1GetFunctionName)
	(JNIEnv *env, jclass that, jint index)
{
	return (*env)->NewStringUTF(env, JNI_nativeFunctionNames[index]);
}

JNIEXPORT jint JNICALL STATS_NATIVE(JNI_1GetFunctionCallCount)
	(JNIEnv *env, jclass that, jint index)
{
	return JNI_nativeFunctionCallCount[index];
}

#endif


#include "ball-util.h"
#include "hawtjni.h"
#include "ball-util_structs.h"
#include "ball-util_stats.h"

#define JNI_NATIVE(func) Java_ball_util_JNI_##func

JNIEXPORT void JNICALL JNI_NATIVE(init)(JNIEnv *env, jclass that)
{
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "_DARWIN_FEATURE_64_BIT_INODE", "I"), (jint)_DARWIN_FEATURE_64_BIT_INODE);
   return;
}
JNIEXPORT void JNICALL JNI_NATIVE(uuid_1clear)
	(JNIEnv *env, jclass that, jlongArray arg0)
{
	jlong *lparg0=NULL;
	JNI_NATIVE_ENTER(env, that, JNI_uuid_1clear_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	uuid_clear(lparg0);
fail:
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	JNI_NATIVE_EXIT(env, that, JNI_uuid_1clear_FUNC);
}

JNIEXPORT void JNICALL JNI_NATIVE(uuid_1generate)
	(JNIEnv *env, jclass that, jlongArray arg0)
{
	jlong *lparg0=NULL;
	JNI_NATIVE_ENTER(env, that, JNI_uuid_1generate_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	uuid_generate(lparg0);
fail:
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	JNI_NATIVE_EXIT(env, that, JNI_uuid_1generate_FUNC);
}

JNIEXPORT void JNICALL JNI_NATIVE(uuid_1generate_1random)
	(JNIEnv *env, jclass that, jlongArray arg0)
{
	jlong *lparg0=NULL;
	JNI_NATIVE_ENTER(env, that, JNI_uuid_1generate_1random_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	uuid_generate_random(lparg0);
fail:
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	JNI_NATIVE_EXIT(env, that, JNI_uuid_1generate_1random_FUNC);
}

JNIEXPORT void JNICALL JNI_NATIVE(uuid_1generate_1time)
	(JNIEnv *env, jclass that, jlongArray arg0)
{
	jlong *lparg0=NULL;
	JNI_NATIVE_ENTER(env, that, JNI_uuid_1generate_1time_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	uuid_generate_time(lparg0);
fail:
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	JNI_NATIVE_EXIT(env, that, JNI_uuid_1generate_1time_FUNC);
}


/*-
 * ##########################################################################
 * Utilities
 * $Id: ball-util.h 5285 2020-02-05 04:23:21Z ball $
 * $HeadURL: svn+ssh://localhost/Users/ball/.repository/ball.util/trunk/src/main/native-package/src/ball-util.h $
 * %%
 * Copyright (C) 2008 - 2020 Allen D. Ball
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ##########################################################################
 */
#ifndef BALL_UTIL_H
#define BALL_UTIL_H

#include <uuid/uuid.h>

#ifndef _DARWIN_FEATURE_64_BIT_INODE
#define _DARWIN_FEATURE_64_BIT_INODE 0
#endif

#endif

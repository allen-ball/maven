
#include "hawtjni.h"
#include "silicondust_stats.h"

#ifdef NATIVE_STATS

int LibHDHomeRun_nativeFunctionCount = 1;
int LibHDHomeRun_nativeFunctionCallCount[1];
char * LibHDHomeRun_nativeFunctionNames[] = {
	"init",
};

#define STATS_NATIVE(func) Java_org_fusesource_hawtjni_runtime_NativeStats_##func

JNIEXPORT jint JNICALL STATS_NATIVE(LibHDHomeRun_1GetFunctionCount)
	(JNIEnv *env, jclass that)
{
	return LibHDHomeRun_nativeFunctionCount;
}

JNIEXPORT jstring JNICALL STATS_NATIVE(LibHDHomeRun_1GetFunctionName)
	(JNIEnv *env, jclass that, jint index)
{
	return (*env)->NewStringUTF(env, LibHDHomeRun_nativeFunctionNames[index]);
}

JNIEXPORT jint JNICALL STATS_NATIVE(LibHDHomeRun_1GetFunctionCallCount)
	(JNIEnv *env, jclass that, jint index)
{
	return LibHDHomeRun_nativeFunctionCallCount[index];
}

#endif

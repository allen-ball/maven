/* $Id: silicondust.h 6925 2020-10-27 15:13:35Z ball $ */
#ifndef SILICONDUST_H
#define SILICONDUST_H

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef __APPLE__
#import <objc/objc-runtime.h>
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#ifdef HAVE_STRINGS_H
#include <string.h>
#endif

#include <hdhomerun.h>

#endif

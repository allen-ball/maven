
#include "hawtjni.h"
#include "videolan-libdvdnav_stats.h"

#ifdef NATIVE_STATS

int DVDNav_nativeFunctionCount = 70;
int DVDNav_nativeFunctionCallCount[70];
char * DVDNav_nativeFunctionNames[] = {
	"dvdnav_1angle_1change",
	"dvdnav_1audio_1language_1select",
	"dvdnav_1audio_1stream_1channels",
	"dvdnav_1audio_1stream_1format",
	"dvdnav_1audio_1stream_1to_1lang",
	"dvdnav_1button_1activate",
	"dvdnav_1button_1select",
	"dvdnav_1button_1select_1and_1activate",
	"dvdnav_1close",
	"dvdnav_1current_1title_1info",
	"dvdnav_1current_1title_1program",
	"dvdnav_1dup",
	"dvdnav_1err_1to_1string",
	"dvdnav_1free_1dup",
	"dvdnav_1get_1PGC_1positioning_1flag",
	"dvdnav_1get_1active_1audio_1stream",
	"dvdnav_1get_1active_1spu_1stream",
	"dvdnav_1get_1angle_1info",
	"dvdnav_1get_1audio_1logical_1stream",
	"dvdnav_1get_1current_1highlight",
	"dvdnav_1get_1current_1nav_1dsi",
	"dvdnav_1get_1current_1nav_1pci",
	"dvdnav_1get_1current_1time",
	"dvdnav_1get_1next_1block",
	"dvdnav_1get_1next_1still_1flag",
	"dvdnav_1get_1number_1of_1parts",
	"dvdnav_1get_1number_1of_1titles",
	"dvdnav_1get_1position",
	"dvdnav_1get_1readahead_1flag",
	"dvdnav_1get_1region_1mask",
	"dvdnav_1get_1serial_1string",
	"dvdnav_1get_1spu_1logical_1stream",
	"dvdnav_1get_1title_1string",
	"dvdnav_1get_1video_1aspect",
	"dvdnav_1get_1video_1resolution",
	"dvdnav_1get_1video_1scale_1permission",
	"dvdnav_1go_1up",
	"dvdnav_1is_1domain_1fp",
	"dvdnav_1is_1domain_1vmgm",
	"dvdnav_1is_1domain_1vts",
	"dvdnav_1is_1domain_1vtsm",
	"dvdnav_1left_1button_1select",
	"dvdnav_1lower_1button_1select",
	"dvdnav_1menu_1language_1select",
	"dvdnav_1mouse_1activate",
	"dvdnav_1mouse_1select",
	"dvdnav_1next_1pg_1search",
	"dvdnav_1open",
	"dvdnav_1part_1search",
	"dvdnav_1prev_1pg_1search",
	"dvdnav_1program_1play",
	"dvdnav_1reset",
	"dvdnav_1right_1button_1select",
	"dvdnav_1sector_1search",
	"dvdnav_1set_1PGC_1positioning_1flag",
	"dvdnav_1set_1readahead_1flag",
	"dvdnav_1set_1region_1mask",
	"dvdnav_1spu_1language_1select",
	"dvdnav_1spu_1stream_1to_1lang",
	"dvdnav_1still_1skip",
	"dvdnav_1stop",
	"dvdnav_1time_1search",
	"dvdnav_1title_1play",
	"dvdnav_1top_1pg_1search",
	"dvdnav_1upper_1button_1select",
	"dvdnav_1version",
	"dvdnav_1wait_1skip",
	"init",
	"memmove",
	"strlen",
};

#define STATS_NATIVE(func) Java_org_fusesource_hawtjni_runtime_NativeStats_##func

JNIEXPORT jint JNICALL STATS_NATIVE(DVDNav_1GetFunctionCount)
	(JNIEnv *env, jclass that)
{
	return DVDNav_nativeFunctionCount;
}

JNIEXPORT jstring JNICALL STATS_NATIVE(DVDNav_1GetFunctionName)
	(JNIEnv *env, jclass that, jint index)
{
	return (*env)->NewStringUTF(env, DVDNav_nativeFunctionNames[index]);
}

JNIEXPORT jint JNICALL STATS_NATIVE(DVDNav_1GetFunctionCallCount)
	(JNIEnv *env, jclass that, jint index)
{
	return DVDNav_nativeFunctionCallCount[index];
}

#endif

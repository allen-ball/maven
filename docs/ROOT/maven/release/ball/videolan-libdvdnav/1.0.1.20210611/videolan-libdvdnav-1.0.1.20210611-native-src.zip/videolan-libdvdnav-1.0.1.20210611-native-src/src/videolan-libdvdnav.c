
#include "videolan-libdvdnav.h"
#include "hawtjni.h"
#include "videolan-libdvdnav_structs.h"
#include "videolan-libdvdnav_stats.h"

#define DVDNav_NATIVE(func) Java_videolan_libdvdnav_DVDNav_##func

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1angle_1change)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1angle_1change_FUNC);
	rc = (jint)dvdnav_angle_change((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1angle_1change_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1audio_1language_1select)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1)
{
	const char *lparg1= NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1audio_1language_1select_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_audio_language_select((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1audio_1language_1select_FUNC);
	return rc;
}

JNIEXPORT jchar JNICALL DVDNav_NATIVE(dvdnav_1audio_1stream_1channels)
	(JNIEnv *env, jclass that, jlong arg0, jbyte arg1)
{
	jchar rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1audio_1stream_1channels_FUNC);
	rc = (jchar)dvdnav_audio_stream_channels((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1audio_1stream_1channels_FUNC);
	return rc;
}

JNIEXPORT jchar JNICALL DVDNav_NATIVE(dvdnav_1audio_1stream_1format)
	(JNIEnv *env, jclass that, jlong arg0, jbyte arg1)
{
	jchar rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1audio_1stream_1format_FUNC);
	rc = (jchar)dvdnav_audio_stream_format((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1audio_1stream_1format_FUNC);
	return rc;
}

JNIEXPORT jchar JNICALL DVDNav_NATIVE(dvdnav_1audio_1stream_1to_1lang)
	(JNIEnv *env, jclass that, jlong arg0, jbyte arg1)
{
	jchar rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1audio_1stream_1to_1lang_FUNC);
	rc = (jchar)dvdnav_audio_stream_to_lang((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1audio_1stream_1to_1lang_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1button_1activate)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1button_1activate_FUNC);
	rc = (jint)dvdnav_button_activate((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1button_1activate_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1button_1select)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jint arg2)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1button_1select_FUNC);
	rc = (jint)dvdnav_button_select((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1, arg2);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1button_1select_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1button_1select_1and_1activate)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jint arg2)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1button_1select_1and_1activate_FUNC);
	rc = (jint)dvdnav_button_select_and_activate((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1, arg2);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1button_1select_1and_1activate_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1close)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1close_FUNC);
	rc = (jint)dvdnav_close((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1close_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1current_1title_1info)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1, jintArray arg2)
{
	jint *lparg1=NULL;
	jint *lparg2=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1current_1title_1info_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_current_title_info((dvdnav_t *)(intptr_t)arg0, lparg1, lparg2);
fail:
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1current_1title_1info_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1current_1title_1program)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1, jintArray arg2, jintArray arg3)
{
	jint *lparg1=NULL;
	jint *lparg2=NULL;
	jint *lparg3=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1current_1title_1program_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	if (arg3) if ((lparg3 = (*env)->GetIntArrayElements(env, arg3, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_current_title_program((dvdnav_t *)(intptr_t)arg0, lparg1, lparg2, lparg3);
fail:
	if (arg3 && lparg3) (*env)->ReleaseIntArrayElements(env, arg3, lparg3, 0);
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1current_1title_1program_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1dup)
	(JNIEnv *env, jclass that, jlongArray arg0, jlong arg1)
{
	jlong *lparg0=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1dup_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_dup((dvdnav_t **)lparg0, (dvdnav_t *)(intptr_t)arg1);
fail:
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1dup_FUNC);
	return rc;
}

JNIEXPORT jstring JNICALL DVDNav_NATIVE(dvdnav_1err_1to_1string)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jstring rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1err_1to_1string_FUNC);
	rc = (jstring)dvdnav_err_to_string((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1err_1to_1string_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1free_1dup)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1free_1dup_FUNC);
	rc = (jint)dvdnav_free_dup((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1free_1dup_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1PGC_1positioning_1flag)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1)
{
	jint *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1PGC_1positioning_1flag_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_PGC_positioning_flag((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1PGC_1positioning_1flag_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1get_1active_1audio_1stream)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1active_1audio_1stream_FUNC);
	rc = (jbyte)dvdnav_get_active_audio_stream((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1active_1audio_1stream_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1get_1active_1spu_1stream)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1active_1spu_1stream_FUNC);
	rc = (jbyte)dvdnav_get_active_spu_stream((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1active_1spu_1stream_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1angle_1info)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1, jintArray arg2)
{
	jint *lparg1=NULL;
	jint *lparg2=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1angle_1info_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_angle_info((dvdnav_t *)(intptr_t)arg0, lparg1, lparg2);
fail:
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1angle_1info_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1get_1audio_1logical_1stream)
	(JNIEnv *env, jclass that, jlong arg0, jbyte arg1)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1audio_1logical_1stream_FUNC);
	rc = (jbyte)dvdnav_get_audio_logical_stream((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1audio_1logical_1stream_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1current_1highlight)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1)
{
	jint *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1current_1highlight_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_current_highlight((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1current_1highlight_FUNC);
	return rc;
}

JNIEXPORT jlong JNICALL DVDNav_NATIVE(dvdnav_1get_1current_1nav_1dsi)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jlong rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1current_1nav_1dsi_FUNC);
	rc = (jlong)dvdnav_get_current_nav_dsi((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1current_1nav_1dsi_FUNC);
	return rc;
}

JNIEXPORT jlong JNICALL DVDNav_NATIVE(dvdnav_1get_1current_1nav_1pci)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jlong rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1current_1nav_1pci_FUNC);
	rc = (jlong)dvdnav_get_current_nav_pci((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1current_1nav_1pci_FUNC);
	return rc;
}

JNIEXPORT jlong JNICALL DVDNav_NATIVE(dvdnav_1get_1current_1time)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jlong rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1current_1time_FUNC);
	rc = (jlong)dvdnav_get_current_time((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1current_1time_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1next_1block)
	(JNIEnv *env, jclass that, jlong arg0, jbyteArray arg1, jintArray arg2, jintArray arg3)
{
	jbyte *lparg1=NULL;
	jint *lparg2=NULL;
	jint *lparg3=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1next_1block_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetByteArrayElements(env, arg1, NULL)) == NULL) goto fail;
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	if (arg3) if ((lparg3 = (*env)->GetIntArrayElements(env, arg3, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_next_block((dvdnav_t *)(intptr_t)arg0, lparg1, lparg2, lparg3);
fail:
	if (arg3 && lparg3) (*env)->ReleaseIntArrayElements(env, arg3, lparg3, 0);
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	if (arg1 && lparg1) (*env)->ReleaseByteArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1next_1block_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1next_1still_1flag)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1next_1still_1flag_FUNC);
	rc = (jint)dvdnav_get_next_still_flag((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1next_1still_1flag_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1number_1of_1parts)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1, jintArray arg2)
{
	jint *lparg2=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1number_1of_1parts_FUNC);
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_number_of_parts((dvdnav_t *)(intptr_t)arg0, arg1, lparg2);
fail:
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1number_1of_1parts_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1number_1of_1titles)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1)
{
	jint *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1number_1of_1titles_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_number_of_titles((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1number_1of_1titles_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1position)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1, jintArray arg2)
{
	jint *lparg1=NULL;
	jint *lparg2=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1position_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_position((dvdnav_t *)(intptr_t)arg0, lparg1, lparg2);
fail:
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1position_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1readahead_1flag)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1)
{
	jint *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1readahead_1flag_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_readahead_flag((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1readahead_1flag_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1region_1mask)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1)
{
	jint *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1region_1mask_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_region_mask((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1region_1mask_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1serial_1string)
	(JNIEnv *env, jclass that, jlong arg0, jlongArray arg1)
{
	jlong *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1serial_1string_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetLongArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_serial_string((dvdnav_t *)(intptr_t)arg0, (const char **)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseLongArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1serial_1string_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1get_1spu_1logical_1stream)
	(JNIEnv *env, jclass that, jlong arg0, jbyte arg1)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1spu_1logical_1stream_FUNC);
	rc = (jbyte)dvdnav_get_spu_logical_stream((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1spu_1logical_1stream_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1title_1string)
	(JNIEnv *env, jclass that, jlong arg0, jlongArray arg1)
{
	jlong *lparg1=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1title_1string_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetLongArrayElements(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_title_string((dvdnav_t *)(intptr_t)arg0, (const char **)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseLongArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1title_1string_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1get_1video_1aspect)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1video_1aspect_FUNC);
	rc = (jbyte)dvdnav_get_video_aspect((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1video_1aspect_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1get_1video_1resolution)
	(JNIEnv *env, jclass that, jlong arg0, jintArray arg1, jintArray arg2)
{
	jint *lparg1=NULL;
	jint *lparg2=NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1video_1resolution_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetIntArrayElements(env, arg1, NULL)) == NULL) goto fail;
	if (arg2) if ((lparg2 = (*env)->GetIntArrayElements(env, arg2, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_get_video_resolution((dvdnav_t *)(intptr_t)arg0, lparg1, lparg2);
fail:
	if (arg2 && lparg2) (*env)->ReleaseIntArrayElements(env, arg2, lparg2, 0);
	if (arg1 && lparg1) (*env)->ReleaseIntArrayElements(env, arg1, lparg1, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1video_1resolution_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1get_1video_1scale_1permission)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1get_1video_1scale_1permission_FUNC);
	rc = (jbyte)dvdnav_get_video_scale_permission((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1get_1video_1scale_1permission_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1go_1up)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1go_1up_FUNC);
	rc = (jint)dvdnav_go_up((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1go_1up_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1is_1domain_1fp)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1is_1domain_1fp_FUNC);
	rc = (jbyte)dvdnav_is_domain_fp((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1is_1domain_1fp_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1is_1domain_1vmgm)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1is_1domain_1vmgm_FUNC);
	rc = (jbyte)dvdnav_is_domain_vmgm((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1is_1domain_1vmgm_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1is_1domain_1vts)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1is_1domain_1vts_FUNC);
	rc = (jbyte)dvdnav_is_domain_vts((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1is_1domain_1vts_FUNC);
	return rc;
}

JNIEXPORT jbyte JNICALL DVDNav_NATIVE(dvdnav_1is_1domain_1vtsm)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jbyte rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1is_1domain_1vtsm_FUNC);
	rc = (jbyte)dvdnav_is_domain_vtsm((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1is_1domain_1vtsm_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1left_1button_1select)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1left_1button_1select_FUNC);
	rc = (jint)dvdnav_left_button_select((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1left_1button_1select_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1lower_1button_1select)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1lower_1button_1select_FUNC);
	rc = (jint)dvdnav_lower_button_select((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1lower_1button_1select_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1menu_1language_1select)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1)
{
	const char *lparg1= NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1menu_1language_1select_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_menu_language_select((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1menu_1language_1select_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1mouse_1activate)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jint arg2, jint arg3)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1mouse_1activate_FUNC);
	rc = (jint)dvdnav_mouse_activate((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1, arg2, arg3);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1mouse_1activate_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1mouse_1select)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jint arg2, jint arg3)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1mouse_1select_FUNC);
	rc = (jint)dvdnav_mouse_select((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1, arg2, arg3);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1mouse_1select_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1next_1pg_1search)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1next_1pg_1search_FUNC);
	rc = (jint)dvdnav_next_pg_search((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1next_1pg_1search_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1open)
	(JNIEnv *env, jclass that, jlongArray arg0, jstring arg1)
{
	jlong *lparg0=NULL;
	const char *lparg1= NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1open_FUNC);
	if (arg0) if ((lparg0 = (*env)->GetLongArrayElements(env, arg0, NULL)) == NULL) goto fail;
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_open((dvdnav_t **)lparg0, (const char *)lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	if (arg0 && lparg0) (*env)->ReleaseLongArrayElements(env, arg0, lparg0, 0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1open_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1part_1search)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1part_1search_FUNC);
	rc = (jint)dvdnav_part_search((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1part_1search_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1prev_1pg_1search)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1prev_1pg_1search_FUNC);
	rc = (jint)dvdnav_prev_pg_search((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1prev_1pg_1search_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1program_1play)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1, jint arg2, jint arg3)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1program_1play_FUNC);
	rc = (jint)dvdnav_program_play((dvdnav_t *)(intptr_t)arg0, arg1, arg2, arg3);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1program_1play_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1reset)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1reset_FUNC);
	rc = (jint)dvdnav_reset((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1reset_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1right_1button_1select)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1right_1button_1select_FUNC);
	rc = (jint)dvdnav_right_button_select((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1right_1button_1select_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1sector_1search)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1, jint arg2)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1sector_1search_FUNC);
	rc = (jint)dvdnav_sector_search((dvdnav_t *)(intptr_t)arg0, arg1, arg2);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1sector_1search_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1set_1PGC_1positioning_1flag)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1set_1PGC_1positioning_1flag_FUNC);
	rc = (jint)dvdnav_set_PGC_positioning_flag((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1set_1PGC_1positioning_1flag_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1set_1readahead_1flag)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1set_1readahead_1flag_FUNC);
	rc = (jint)dvdnav_set_readahead_flag((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1set_1readahead_1flag_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1set_1region_1mask)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1set_1region_1mask_FUNC);
	rc = (jint)dvdnav_set_region_mask((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1set_1region_1mask_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1spu_1language_1select)
	(JNIEnv *env, jclass that, jlong arg0, jstring arg1)
{
	const char *lparg1= NULL;
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1spu_1language_1select_FUNC);
	if (arg1) if ((lparg1 = (*env)->GetStringUTFChars(env, arg1, NULL)) == NULL) goto fail;
	rc = (jint)dvdnav_spu_language_select((dvdnav_t *)(intptr_t)arg0, lparg1);
fail:
	if (arg1 && lparg1) (*env)->ReleaseStringUTFChars(env, arg1, lparg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1spu_1language_1select_FUNC);
	return rc;
}

JNIEXPORT jchar JNICALL DVDNav_NATIVE(dvdnav_1spu_1stream_1to_1lang)
	(JNIEnv *env, jclass that, jlong arg0, jbyte arg1)
{
	jchar rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1spu_1stream_1to_1lang_FUNC);
	rc = (jchar)dvdnav_spu_stream_to_lang((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1spu_1stream_1to_1lang_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1still_1skip)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1still_1skip_FUNC);
	rc = (jint)dvdnav_still_skip((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1still_1skip_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1stop)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1stop_FUNC);
	rc = (jint)dvdnav_stop((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1stop_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1time_1search)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1time_1search_FUNC);
	rc = (jint)dvdnav_time_search((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1time_1search_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1title_1play)
	(JNIEnv *env, jclass that, jlong arg0, jint arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1title_1play_FUNC);
	rc = (jint)dvdnav_title_play((dvdnav_t *)(intptr_t)arg0, arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1title_1play_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1top_1pg_1search)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1top_1pg_1search_FUNC);
	rc = (jint)dvdnav_top_pg_search((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1top_1pg_1search_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1upper_1button_1select)
	(JNIEnv *env, jclass that, jlong arg0, jlong arg1)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1upper_1button_1select_FUNC);
	rc = (jint)dvdnav_upper_button_select((dvdnav_t *)(intptr_t)arg0, (pci_t *)(intptr_t)arg1);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1upper_1button_1select_FUNC);
	return rc;
}

JNIEXPORT jstring JNICALL DVDNav_NATIVE(dvdnav_1version)
	(JNIEnv *env, jclass that)
{
	jstring rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1version_FUNC);
	rc = (jstring)dvdnav_version();
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1version_FUNC);
	return rc;
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(dvdnav_1wait_1skip)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_dvdnav_1wait_1skip_FUNC);
	rc = (jint)dvdnav_wait_skip((dvdnav_t *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_dvdnav_1wait_1skip_FUNC);
	return rc;
}

JNIEXPORT void JNICALL DVDNav_NATIVE(init)(JNIEnv *env, jclass that)
{
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_STATUS_ERR", "I"), (jint)DVDNAV_STATUS_ERR);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_STATUS_OK", "I"), (jint)DVDNAV_STATUS_OK);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_BLOCK_OK", "I"), (jint)DVDNAV_BLOCK_OK);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_NOP", "I"), (jint)DVDNAV_NOP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_STILL_FRAME", "I"), (jint)DVDNAV_STILL_FRAME);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_SPU_STREAM_CHANGE", "I"), (jint)DVDNAV_SPU_STREAM_CHANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_AUDIO_STREAM_CHANGE", "I"), (jint)DVDNAV_AUDIO_STREAM_CHANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_VTS_CHANGE", "I"), (jint)DVDNAV_VTS_CHANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_CELL_CHANGE", "I"), (jint)DVDNAV_CELL_CHANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_NAV_PACKET", "I"), (jint)DVDNAV_NAV_PACKET);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_STOP", "I"), (jint)DVDNAV_STOP);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_HIGHLIGHT", "I"), (jint)DVDNAV_HIGHLIGHT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_SPU_CLUT_CHANGE", "I"), (jint)DVDNAV_SPU_CLUT_CHANGE);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_HOP_CHANNEL", "I"), (jint)DVDNAV_HOP_CHANNEL);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVDNAV_WAIT", "I"), (jint)DVDNAV_WAIT);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "DVD_VIDEO_LB_LEN", "I"), (jint)DVD_VIDEO_LB_LEN);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "MAX_UDF_FILE_NAME_LEN", "I"), (jint)MAX_UDF_FILE_NAME_LEN);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "SEEK_SET", "I"), (jint)SEEK_SET);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "SEEK_CUR", "I"), (jint)SEEK_CUR);
	(*env)->SetStaticIntField(env, that, (*env)->GetStaticFieldID(env, that, "SEEK_END", "I"), (jint)SEEK_END);
   return;
}
JNIEXPORT void JNICALL DVDNav_NATIVE(memmove)
	(JNIEnv *env, jclass that, jbyteArray arg0, jlong arg1, jlong arg2)
{
	jbyte *lparg0=NULL;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_memmove_FUNC);
#ifdef JNI_VERSION_1_2
	if (IS_JNI_1_2) {
		if (arg0) if ((lparg0 = (*env)->GetPrimitiveArrayCritical(env, arg0, NULL)) == NULL) goto fail;
	} else
#endif
	{
		if (arg0) if ((lparg0 = (*env)->GetByteArrayElements(env, arg0, NULL)) == NULL) goto fail;
	}
	memmove((void *)lparg0, (const void *)(intptr_t)arg1, (size_t)arg2);
fail:
#ifdef JNI_VERSION_1_2
	if (IS_JNI_1_2) {
		if (arg0 && lparg0) (*env)->ReleasePrimitiveArrayCritical(env, arg0, lparg0, 0);
	} else
#endif
	{
		if (arg0 && lparg0) (*env)->ReleaseByteArrayElements(env, arg0, lparg0, 0);
	}
	DVDNav_NATIVE_EXIT(env, that, DVDNav_memmove_FUNC);
}

JNIEXPORT jint JNICALL DVDNav_NATIVE(strlen)
	(JNIEnv *env, jclass that, jlong arg0)
{
	jint rc = 0;
	DVDNav_NATIVE_ENTER(env, that, DVDNav_strlen_FUNC);
	rc = (jint)strlen((char *)(intptr_t)arg0);
	DVDNav_NATIVE_EXIT(env, that, DVDNav_strlen_FUNC);
	return rc;
}


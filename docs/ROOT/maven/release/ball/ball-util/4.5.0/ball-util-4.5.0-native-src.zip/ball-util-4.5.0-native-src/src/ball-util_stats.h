
#ifdef NATIVE_STATS
extern int JNI_nativeFunctionCount;
extern int JNI_nativeFunctionCallCount[];
extern char* JNI_nativeFunctionNames[];
#define JNI_NATIVE_ENTER(env, that, func) JNI_nativeFunctionCallCount[func]++;
#define JNI_NATIVE_EXIT(env, that, func) 
#else
#ifndef JNI_NATIVE_ENTER
#define JNI_NATIVE_ENTER(env, that, func) 
#endif
#ifndef JNI_NATIVE_EXIT
#define JNI_NATIVE_EXIT(env, that, func) 
#endif
#endif

typedef enum {
	JNI_init_FUNC,
	JNI_uuid_1clear_FUNC,
	JNI_uuid_1generate_FUNC,
	JNI_uuid_1generate_1random_FUNC,
	JNI_uuid_1generate_1time_FUNC,
} JNI_FUNCS;


#ifdef NATIVE_STATS
extern int LibHDHomeRun_nativeFunctionCount;
extern int LibHDHomeRun_nativeFunctionCallCount[];
extern char* LibHDHomeRun_nativeFunctionNames[];
#define LibHDHomeRun_NATIVE_ENTER(env, that, func) LibHDHomeRun_nativeFunctionCallCount[func]++;
#define LibHDHomeRun_NATIVE_EXIT(env, that, func) 
#else
#ifndef LibHDHomeRun_NATIVE_ENTER
#define LibHDHomeRun_NATIVE_ENTER(env, that, func) 
#endif
#ifndef LibHDHomeRun_NATIVE_EXIT
#define LibHDHomeRun_NATIVE_EXIT(env, that, func) 
#endif
#endif

typedef enum {
	LibHDHomeRun_init_FUNC,
} LibHDHomeRun_FUNCS;

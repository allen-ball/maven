
#include "silicondust.h"
#include "hawtjni.h"
#include "silicondust_structs.h"
#include "silicondust_stats.h"

#define LibHDHomeRun_NATIVE(func) Java_silicondust_LibHDHomeRun_##func

